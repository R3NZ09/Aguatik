import { useState } from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  LineElement,
  PointElement,
  CategoryScale,
  LinearScale,
  Legend,
  Tooltip
} from 'chart.js';
import './App.css';

ChartJS.register(LineElement, PointElement, CategoryScale, LinearScale, Legend, Tooltip);

function StatCard({ label, sublabel, value, unit, iconColor = '#3b82f6' }) {
  return (
    <div className="card stat">
      <div className="stat-header">
        <span className="stat-icon" style={{ backgroundColor: iconColor }} />
        <div className="stat-meta">
          <div className="stat-label">{label}</div>
          <div className="stat-sublabel">{sublabel}</div>
        </div>
      </div>
      <div className="stat-value">
        <strong>{value}</strong> {unit}
      </div>
    </div>
  );
}

function Toggle({ checked, onChange, label, icon }) {
  return (
    <div className="toggle-container">
      <div className="toggle-label">
        <span className="toggle-icon">{icon}</span>
        <span>{label}</span>
      </div>
      <button 
        className={`toggle ${checked ? 'on' : ''}`} 
        onClick={() => onChange(!checked)} 
        aria-pressed={checked}
        aria-label={`Toggle ${label}`}
      >
        <span className="knob" />
      </button>
    </div>
  );
}

function App() {
  const [actuators, setActuators] = useState({
    aerator: true,
    pump: false,
    heater: false,
    feeder: false
  });

  const handleToggle = (actuator) => {
    setActuators(prev => ({
      ...prev,
      [actuator]: !prev[actuator]
    }));
  };

  const labels = ['8:09:10 PM', '8:09:15 PM', '8:09:20 PM', '8:09:25 PM'];
  const data = {
    labels,
    datasets: [
      { 
        label: 'Dissolved Oxygen (DO)', 
        borderColor: '#00d4ff', 
        backgroundColor: 'rgba(0, 212, 255, 0.1)', 
        data: [6, 6, 6, 6], 
        tension: 0.3,
        borderWidth: 3,
        pointRadius: 4,
        pointHoverRadius: 6
      },
      { 
        label: 'pH', 
        borderColor: '#ff4757', 
        backgroundColor: 'rgba(255, 71, 87, 0.1)', 
        data: [8.1, 8.1, 8.1, 8.1], 
        tension: 0.3,
        borderWidth: 3,
        pointRadius: 4,
        pointHoverRadius: 6
      },
      { 
        label: 'Salinity', 
        borderColor: '#2ed573', 
        backgroundColor: 'rgba(46, 213, 115, 0.1)', 
        data: [34, 34, 34, 34], 
        tension: 0.3,
        borderWidth: 3,
        pointRadius: 4,
        pointHoverRadius: 6
      },
      { 
        label: 'Temperature', 
        borderColor: '#ffa502', 
        backgroundColor: 'rgba(255, 165, 2, 0.1)', 
        data: [26, 26, 26, 26], 
        tension: 0.3,
        borderWidth: 3,
        pointRadius: 4,
        pointHoverRadius: 6
      }
    ]
  };
  
  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { 
        position: 'bottom', 
        labels: { 
          color: '#f8fafc',
          usePointStyle: true,
          padding: 20,
          font: {
            size: 12,
            weight: '500'
          }
        } 
      },
      tooltip: { 
        mode: 'index', 
        intersect: false,
        backgroundColor: 'rgba(17, 24, 39, 0.95)',
        titleColor: '#f8fafc',
        bodyColor: '#f8fafc',
        borderColor: '#374151',
        borderWidth: 1
      }
    },
    scales: {
      x: { 
        ticks: { 
          color: '#94a3b8', 
          maxRotation: 0,
          font: { size: 11 }
        }, 
        grid: { 
          color: 'rgba(148,163,184,0.2)',
          lineWidth: 1
        },
        border: {
          color: '#374151'
        }
      },
      y: { 
        ticks: { 
          color: '#94a3b8',
          font: { size: 11 }
        }, 
        grid: { 
          color: 'rgba(148,163,184,0.2)',
          lineWidth: 1
        },
        border: {
          color: '#374151'
        }
      }
    },
    interaction: {
      mode: 'index',
      intersect: false
    },
    elements: {
      point: {
        hoverBorderWidth: 3
      }
    }
  };

  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <div className="title">AguaTek · Aquaculture Control Dashboard</div>
        <button className="settings-btn" aria-label="Open settings">Settings</button>
      </header>

      <section className="stats-grid">
        <StatCard 
          label="Temperature" 
          sublabel="24–28 °C" 
          value={26} 
          unit="°C" 
          iconColor="#60a5fa" 
        />
        <StatCard 
          label="Salinity" 
          sublabel="33–35 PSU" 
          value={34} 
          unit="PSU" 
          iconColor="#22c55e" 
        />
        <StatCard 
          label="pH" 
          sublabel="7.8–8.4" 
          value={8.1} 
          unit="" 
          iconColor="#ff6b6b" 
        />
        <StatCard 
          label="Dissolved Oxygen" 
          sublabel="5–7 mg/L" 
          value={6} 
          unit="mg/L" 
          iconColor="#00b4d8" 
        />
      </section>

      <section className="chart-panel">
        <div className="panel-header">
          <div>
            <div className="panel-title">Parameter Trends</div>
            <div className="panel-subtitle">Real-time monitoring</div>
          </div>
          <select className="time-selector" aria-label="Select time range">
            <option value="1h">Last hour</option>
            <option value="6h">Last 6 hours</option>
            <option value="24h">Last 24 hours</option>
          </select>
        </div>
        <div className="chart-container">
          <Line data={data} options={options} />
        </div>
      </section>

      <section className="grid-2">
        <div className="panel">
          <div className="panel-title">System Controls</div>
          <div className="panel-subtitle">Manual/Auto Parameter Control</div>
          <div className="form">
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="temperature">Temperature (°C)</label>
                <input 
                  id="temperature"
                  type="number" 
                  defaultValue="26" 
                  min="24" 
                  max="28" 
                  step="0.1" 
                  aria-label="Temperature in Celsius"
                />
              </div>
              <div className="form-group">
                <label htmlFor="salinity">Salinity (PSU)</label>
                <input 
                  id="salinity"
                  type="number" 
                  defaultValue="34" 
                  min="33" 
                  max="35" 
                  step="0.1" 
                  aria-label="Salinity in PSU"
                />
              </div>
            </div>
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="ph">pH</label>
                <input 
                  id="ph"
                  type="number" 
                  defaultValue="8.1" 
                  min="7.8" 
                  max="8.4" 
                  step="0.1" 
                  aria-label="pH level"
                />
              </div>
              <div className="form-group">
                <label htmlFor="oxygen">Dissolved Oxygen (mg/L)</label>
                <input 
                  id="oxygen"
                  type="number" 
                  defaultValue="6" 
                  min="5" 
                  max="7" 
                  step="0.1" 
                  aria-label="Dissolved oxygen in mg per liter"
                />
              </div>
            </div>
            <button className="btn primary" aria-label="Apply parameter changes">Apply Changes</button>
          </div>
        </div>
        <div className="panel">
          <div className="panel-title">Actuators</div>
          <div className="panel-subtitle">Real-time Device Control</div>
          <div className="actuators">
            <Toggle 
              label="Aerator" 
              icon="💨"
              checked={actuators.aerator} 
              onChange={() => handleToggle('aerator')} 
            />
            <Toggle 
              label="Pump" 
              icon="💧"
              checked={actuators.pump} 
              onChange={() => handleToggle('pump')} 
            />
            <Toggle 
              label="Heater" 
              icon="🔥"
              checked={actuators.heater} 
              onChange={() => handleToggle('heater')} 
            />
            <Toggle 
              label="Feeder" 
              icon="🌾"
              checked={actuators.feeder} 
              onChange={() => handleToggle('feeder')} 
            />
          </div>
        </div>
      </section>

      <section className="grid-3">
        <div className="panel">
          <div className="panel-title warn">Alerts</div>
          <div className="alert-status">
            <span className="status-indicator success"></span>
            <span>All parameters within range.</span>
          </div>
        </div>
        <div className="panel">
          <div className="panel-title">Activity Log</div>
          <ul className="log">
            <li><span className="time">09:32</span> Auto-adjusted aerator duty cycle to maintain DO ≥ 5 mg/L</li>
            <li><span className="time">09:10</span> User updated target temperature to 26°C</li>
            <li><span className="time">08:55</span> Species set to Amphiprion Ocellaris (Clownfish)</li>
          </ul>
        </div>
        <div className="panel">
          <div className="panel-title">Calibration & Maintenance</div>
          <div className="maintenance-actions">
            <button className="btn primary block" aria-label="Run quick calibration">Run Quick Calibration</button>
            <button className="btn block" aria-label="Schedule maintenance">Schedule Maintenance</button>
          </div>
        </div>
      </section>
    </div>
  );
}

export default App;