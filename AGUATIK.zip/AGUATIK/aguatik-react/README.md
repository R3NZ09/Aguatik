# AguaTek - Aquaculture Control Dashboard

A modern React-based dashboard for monitoring and controlling aquaculture systems. Built with React 19, Vite, and Chart.js for real-time data visualization and system control.

![Dashboard Preview](https://via.placeholder.com/800x400/0a0d14/f8fafc?text=AguaTek+Dashboard)

## ✨ Features

- **Real-time Monitoring**: Track Temperature, Salinity, pH, and Dissolved Oxygen levels
- **Interactive Controls**: Toggle devices like Aerator, Pump, Heater, and Feeder
- **Data Visualization**: Beautiful charts showing parameter trends over time
- **Activity Logging**: Track system events and user actions
- **Responsive Design**: Works perfectly on desktop, tablet, and mobile devices
- **Modern UI**: Clean, dark-themed interface with smooth animations

## 🚀 Getting Started

### Prerequisites
- Node.js (version 16 or higher)
- npm or yarn

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/YOUR_USERNAME/aguatik-react.git
   cd aguatik-react
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the development server**
   ```bash
   npm run dev
   ```

4. **Open your browser**
   Navigate to `http://localhost:5174`

## 🛠️ Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint

## 📱 Responsive Design

The dashboard is fully responsive and optimized for:
- **Desktop** (1200px+): Full 4-column layout
- **Tablet** (768px-1199px): 2-column adaptive layout
- **Mobile** (480px-767px): Single column stack
- **Small Mobile** (<480px): Compact layout

## 🎨 Tech Stack

- **Frontend**: React 19, Vite
- **Charts**: Chart.js with react-chartjs-2
- **Styling**: CSS3 with CSS Grid and Flexbox
- **Icons**: Emoji-based icons for better compatibility
- **Build Tool**: Vite for fast development and building

## 📊 Dashboard Components

### Parameter Monitoring
- **Temperature**: 24-28°C range monitoring
- **Salinity**: 33-35 PSU range monitoring  
- **pH**: 7.8-8.4 range monitoring
- **Dissolved Oxygen**: 5-7 mg/L range monitoring

### Device Controls
- **Aerator** 💨: Oxygenation control
- **Pump** 💧: Water circulation control
- **Heater** 🔥: Temperature regulation
- **Feeder** 🌾: Automated feeding system

### Data Visualization
- Real-time parameter trends
- Time-based data analysis
- Interactive chart controls
- Multiple time range selections

## 🔧 Configuration

The dashboard uses a clean, modular component structure:

```
src/
├── App.jsx          # Main dashboard component
├── App.css          # Dashboard styles
├── main.jsx         # Application entry point
└── index.css        # Global styles
```

## 🌐 Deployment

### Build for Production
```bash
npm run build
```

### Deploy to GitHub Pages
1. Install gh-pages: `npm install --save-dev gh-pages`
2. Add to package.json scripts:
   ```json
   "predeploy": "npm run build",
   "deploy": "gh-pages -d dist"
   ```
3. Deploy: `npm run deploy`

### Deploy to Netlify
1. Build the project: `npm run build`
2. Drag the `dist` folder to [Netlify](https://netlify.com)
3. Your site will be live instantly!

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature-name`
3. Commit changes: `git commit -m 'Add feature'`
4. Push to branch: `git push origin feature-name`
5. Submit a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Built with [React](https://reactjs.org/)
- Charts powered by [Chart.js](https://www.chartjs.org/)
- Development server by [Vite](https://vitejs.dev/)
- Icons by [Emoji](https://emojipedia.org/)

## 📞 Support

If you have any questions or need help, please:
- Open an [Issue](https://github.com/YOUR_USERNAME/aguatik-react/issues)
- Contact: [Your Email]

---

**Made with ❤️ for Aquaculture Management**